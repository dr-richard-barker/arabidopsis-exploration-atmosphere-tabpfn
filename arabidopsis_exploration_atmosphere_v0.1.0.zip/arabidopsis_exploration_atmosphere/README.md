# Arabidopsis exploration-atmosphere omics catalog

Version **0.1.0** | Frozen public-metadata snapshot **2026-10-15**

Author: **Richard John Barker**

A metadata-only catalog for investigating Arabidopsis responses relevant to NASA's nominal 8.2 psia / 34% oxygen exploration atmosphere. Includes low-pressure experiments, oxygen/mechanistic comparators and plant atlas suitability. An exploratory resource, not a systematic review or biological reanalysis.

## Main findings

- 22 canonical records: 16 validated, three weak leads and three exclusions.
- Five pressure-related experiments; none verified at the exact NASA nominal mixture.
- Four 2017 ATH1 GEO subseries: 148 memberships but **130 unique arrays**, with 18 shared across publications.
- GSE308672 measures cell-resolved root hypoxia responses, **not** pressure responses.
- Untreated atlas localization is inferred context, not measured atmospheric differential response.
- 1,952 file inventory rows; **no raw biological files, matrices or metabolite workbooks are included**.

Read `outputs/reports/report_arabidopsis_exploration_atmosphere.md` or the matching editable Word report. Full tables are in `outputs/tables/`; schemas and limitations in `docs/`.

## Quick start: offline catalog

Tested with **CPython 3.11.13**. No credentials, database downloads, HPC or paid services are required.

```bash
uv venv --python 3.11
source .venv/bin/activate
uv pip install -r requirements-lock.txt
uv pip install --no-build-isolation --no-deps -e .
atmos-catalog build
atmos-catalog validate
atmos-catalog report
pytest -p no:cacheprovider
```

With dependencies already installed:

```bash
PYTHONPATH=src python -m atmos_catalog.cli build
PYTHONPATH=src python -m atmos_catalog.cli validate
PYTHONPATH=src python -m atmos_catalog.cli report
```

`build`, `validate`, `report` and `package` **do not access the network**. Rebuilding the frozen release never needs `discover`. CSV outputs are tested for byte-for-byte equivalence; Word container timestamps can differ on independent regenerations.

## Live discovery: explicit opt-in

```bash
atmos-catalog discover --refresh --config config/search.json --work ./private-refresh
# Optional known series/OSDR metadata refresh, still no measurement files:
atmos-catalog discover --refresh --fetch-known --work ./private-refresh
```

Live mode creates a new UTC-stamped review directory and a private bounded API cache. It never replaces the frozen snapshot or promotes new hits into VALIDATED. Safety checks restrict hosts, redirects, response sizes and known measurement/download endpoints. GEO sample requests require self/brief views. Do not add measurement URLs: this is a metadata client, not a general downloader.

Failure, schema, filtering and truncation outcomes are retained. Repository unavailability is **not a negative result**. Supplemental web discovery is recorded but not automatically rerun by the HTTP CLI; repeat those queries manually with a search service when refreshing.

## Curation for a new release

1. Review query configuration and search/provenance ledgers.
2. Retrieve only necessary metadata and small sample annotations.
3. Compare with `data/snapshot/public_facts_2026-10-15.json`, a sanitized factual extract rather than a full API mirror.
4. Save a new dated snapshot. Update its explicitly named path in `catalog.py` and tests, dates, version and report template. Version 0.1.0 intentionally binds its offline build to one reviewed snapshot.
5. Update `curation/studies.json`, `atlases.json` and `decisions.json` with evidence URLs and rationales. Keep contradictions explicit.
6. Run tests, build, validate and report. Review scientific conclusions and sample relationships before packaging.

Canonical records are curated experiments/references, not uniformly publications or accessions. Related subseries remain separate with family IDs and explicit sample overlap. Companion PXD001815/PXD002353 assays share one study record but retain both file sets. SuperSeries, mirrors, OSD/GLDS aliases and deposit versions are not independent experiments.

## Packaging and citation

```bash
atmos-catalog package --zip ./arabidopsis_exploration_atmosphere_v0.1.0.zip
cffconvert --validate
```

The allowlisted ZIP contains code, tests, configuration, curated facts, reports, tables and an internal SHA256 manifest. It excludes private caches, notebooks and local discovery tooling. Recheck a clean extraction before publication.

Original code is **MIT** (`LICENSE`); original report/catalog annotations are **CC BY 4.0** (`LICENSE-DATA`). Third-party source terms remain in force (`THIRD_PARTY_NOTICES.md`). `CITATION.cff` and `.zenodo.json` describe the catalog with supporting software. No DOI is assigned; no upload or publication was performed. See `docs/RELEASE_CHECKLIST.md`.
