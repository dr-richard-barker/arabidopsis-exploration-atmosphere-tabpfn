# Data dictionary

UTF-8 CSV; empty fields mean **unreported, unresolved or not applicable**,
never zero. Booleans are `True/False`. Lists are JSON strings: parse with
`json.loads`, not a comma split. Wide catalogs suit spreadsheet/programmatic use.

## Tables and row units

| Filename | Row unit |
|---|---|
| arabidopsis_omics_MASTER.csv | Canonical experiment/reference/lead, including weak and excluded entries |
| arabidopsis_omics_VALIDATED.csv | Supported subset of MASTER, same columns; not statistical-readiness certification |
| study_design_audit.csv | Catalog record: conditions, replication, pairing, feasibility, limitations |
| sample_condition_audit.csv | Study-by-GSM membership; reused GSMs appear in both studies |
| condition_group_audit.csv | Study/organ/pressure/O2/duration group; record count is not automatically biological n |
| file_manifest.csv | Repository/assay/filename/sample inventory entry; mirrors remain separate |
| atlas_suitability.csv | Reference or treated-nucleus comparator and direct/inferred role |
| accession_relationships.csv | Explicit mirror/version/companion accession or SuperSeries relationship |
| search_ledger.csv | API query page, including failures/partial coverage |
| supplemental_web_searches.csv | Exact web query, date and result URLs |
| discovery_candidates.csv | Candidate occurrence per query, not deduplicated relevant study |
| provenance_ledger.csv | Factual-extract or curated-evidence source/date/checksum where available |
| additional_lead_decisions.csv | Selected non-priority leads with reason and public locator |

`catalog_metrics.json` supplies counts used by report and validation.

## Catalog fields

- `study_id`: unique canonical key; experimental subseries can differ but
  share `family_id`.
- `aliases`: explicit related accessions, mirrors, versions or companion
  assays; consult `matched_omics`, not every relationship is identity.
- `organism`, `ecotype`, `organ`, `age_stage`: supported material descriptors.
- `modalities`: retain all assay layers; TRAP is ribosome-associated RNA,
  not proteomics or single-cell sequencing.
- `exposure_class`: adjacent hypobaria/oxygen perturbation, related stress,
  reference atlas or out of scope. No exact NASA nominal match is established.
- `relevance`: CORE/DIRECT = pressure experiment, not exact NASA mixture;
  ADJACENT = mechanistic comparator or separately marked reference;
  WEAK = optional/unresolved lead; EXCLUDED = checked and out of scope.
- `role`: treated bulk/nuclei/cell-population/proteome, reference or exclusion.
- `validated`: supported identity, modality, relevance and public availability.
  `validated_definition` explicitly excludes matrix QC/power certification.
- `sample_records`: repository records, not independent biological samples.
- `shared_sample_records_with_other_hypobaria_subseries`: GSMs overlapping
  another priority subseries, not additional samples.
- `conditions`, `replication`, `matched_omics`: design and pairing, including
  unresolved specimen correspondence.
- `readiness`, `feasibility`, `limitations`, `rationale`: curated judgments.
- `source_urls`, `source_indices`: public evidence and original report citation
  labels; citation numbers are labels, not ranks.
- `platform_ids`, `repository_version`, `access`, `rights`, `snapshot_date`:
  metadata where present; no universal license inferred from public access.

## Atmospheric/sample fields

- `pressure_text`, `reported_characteristics`, `sample_title` preserve source
  metadata. `pressure_kpa` is an absolute chamber setpoint, not tissue oxygen.
- `oxygen_fraction`: dimensionless; `oxygen_fraction_basis` separates reported
  nominal fraction from reported-pO2/pressure-derived fraction.
- `po2_reported_kpa`: source pO2, including approximate paper-level setpoints
  where GSMs lack them; `notes` identifies these cases.
- `po2_derived_kpa` = pressure times fraction only when both are available.
  It is not an independent measurement.
- `duration_hours`: reported exposure; no human physiological correction.
- `age_days_reported`, `age_basis`: preserve start/harvest uncertainty.
- `organ_from_title`, `organ_from_characteristics`, `organ_conflict`: preserve
  four contradictory 75 kPa annotations; `organ` remains explicitly unresolved.
- `replicate_label`: deposited label, not proof of independent biology.
  `chamber_id`, `batch_id` stay empty when unavailable.
- `co2_reported`, `temperature_reported`, `humidity_reported`, `light_reported`:
  paper-level covariates with units, not GSM-specific sensor measurements.
- `series_memberships`: experimental memberships excluding SuperSeries.
- `audit_scope`: complete priority-study versus representative-only sampling.
- `source_url`, `source_sha256`, `retrieved_utc`: metadata provenance.

Group `array_or_library_records` counts records.
`independent_biological_n` is deliberately empty: pooling/chamber mapping
was not resolved. Three array records alone do not validate three chambers.

## Files, coverage and source snapshot

`assay_id` retains companion accessions. `category` preserves repository labels;
`archive_content_uninspected` avoids assuming RAW.tar means sequencing reads.
`size_bytes` is exact when supplied; `size_reported` retains rounded values.
`checksum_algorithm` stays missing/untyped if undeclared. URLs may point to
landing pages rather than guessed downloads. No underlying measurement-file
access test or checksum verification was performed.

API `http_status`, `status`, `total_reported`, `retrieved_records`, `page`,
`notes`, `bytes`, `seconds`, `sha256`, `url`, `query`, `retrieved_utc` describe
coverage. “Complete” means the literal query, not exhaustive literature.
Failures, schema issues, unverified filters and truncation are not zeros.
“Not shortlisted” is not an exhaustive manual exclusion of every discovery hit.

`data/snapshot/public_facts_2026-10-15.json` holds sanitized source facts.
`curation/*.json` holds versioned judgments/corrections and evidence locators.
Offline assembly never silently repeats scientific curation. Source rights
remain in force; see THIRD_PARTY_NOTICES.md.
