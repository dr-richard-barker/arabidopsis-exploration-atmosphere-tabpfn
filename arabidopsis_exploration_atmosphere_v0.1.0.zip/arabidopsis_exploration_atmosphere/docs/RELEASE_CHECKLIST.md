# Release checklist

## Local validation

- Run tests, offline build, validate and report.
- Confirm 22 MASTER/16 VALIDATED, 148 memberships/130 unique hypobaria GSMs.
- Preserve four 75 kPa tissue conflicts unless new evidence resolves them.
- Check exposure classes, retained assays and report counts.
- Confirm no measurements, full papers or API caches in the ZIP.
- Run `cffconvert --validate`; check Zenodo required fields and author.
- Read back CSV, Word and ZIP; verify internal SHA256 manifest.
- Clean-extract and test offline commands.
- Check Word widths/fonts/hyperlinks; no embedded figures in this version.

## Before publication

- Review scientific conclusions, source rights and mixed-license notice.
- Supply affiliation/ORCID only if verified and authorized.
- Create a local Git repository if desired; omit private work/cache.
- Upload manually to Zenodo as a dataset with supporting software.
- Review current Zenodo form against the prepared metadata.
- Keep MIT code, CC BY 4.0 original catalog/report and third-party exceptions.
- Add the real DOI to citation metadata only after issuance; never invent one.
- Do not confuse a draft deposition with publication.

No remote repository, upload, DOI reservation or publication was performed.
