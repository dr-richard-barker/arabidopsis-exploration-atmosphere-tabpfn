"""Deterministic, network-free catalog assembly and scientific invariants."""
from __future__ import annotations
from collections import Counter, defaultdict
from pathlib import Path
from urllib.parse import urlparse
import csv
import hashlib
import json
import re

DIRECT=("GSE87867","GSE87868","GSE87903","GSE87904")
PSI_KPA=6.894757293168

def normalize_pressure(value, unit, basis="absolute"):
    if value is None or not unit or basis != "absolute":
        return None
    factor={"kpa":1,"pa":.001,"hpa":.1,"mbar":.1,"bar":100,"psia":PSI_KPA,"atm":101.325}.get(unit.lower())
    if factor is None:
        return None
    number=float(value)
    if number<=0:
        raise ValueError("Absolute pressure must be positive")
    return number*factor

def oxygen_partial_pressure(pressure_kpa, fraction):
    if pressure_kpa is None or fraction is None:
        return None
    if not 0<=fraction<=1:
        raise ValueError("Oxygen fraction must be between0 and1")
    return pressure_kpa*fraction

def canonical_alias(identifier):
    identifier=identifier.strip()
    if identifier.startswith("GLDS-"):
        return identifier.replace("GLDS-","OSD-",1)
    if identifier.startswith("E-GEOD-"):
        return "GSE"+identifier.removeprefix("E-GEOD-")
    return identifier

def scalar(v):
    if v is None:
        return ""
    if isinstance(v,(list,dict)):
        return json.dumps(v,ensure_ascii=False,sort_keys=True)
    return v

def write_csv(path, rows, columns=None):
    if columns is None:
        columns=list(dict.fromkeys(k for row in rows for k in row))
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=columns,extrasaction="raise",lineterminator="\n")
        w.writeheader()
        w.writerows({k:scalar(row.get(k)) for k in columns} for row in rows)

def read_json(path):
    return json.loads(Path(path).read_text())

def sample_audit(snapshot):
    rows=[]
    for gsm,entry in sorted(snapshot["samples"].items()):
        fields=entry["fields"]
        chars=fields.get("Sample_characteristics_ch1",[])
        props={}
        for c in chars:
            key,sep,val=c.partition(": ")
            if sep: props[key.lower()]=val
        title=fields.get("Sample_title",[""])[0]
        exp=props.get("exposed to","")
        pressure=re.search(r"(\d+(?:\.\d+)?)\s*kPa pressure",exp)
        p=float(pressure[1]) if pressure else None
        po2=re.search(r"partial pressure of (\d+(?:\.\d+)?) kPa",exp)
        reported_po2=float(po2[1]) if po2 else None
        duration=re.search(r"for (\d+(?:\.\d+)?) (?:hrs?|hours?)",exp)
        duration=float(duration[1]) if duration else None
        age=re.search(r"(\d+) day",props.get("age",""))
        rep=re.search(r"(?:Replica|Rep|rep)\s*(\d+)",title)
        for g in entry["series"]:
            frac=None; frac_basis=None; p02=reported_po2; notes=[]
            if g in ("GSE87867","GSE87868"):
                if p02 is None and p in (97,50,25):
                    p02={97:21,50:10,25:5}[p]
                    notes.append("pO2 is approximate paper setpoint, not GSM gas-fraction measurement")
                if p02 is not None and p:
                    frac=p02/p
                    frac_basis="derived from reported pO2/total pressure; not reported gas fraction"
            elif g in ("GSE87903","GSE87904"):
                frac=.21;frac_basis="paper nominal 21%v/v"
                if p==97:
                    p02=21
                    notes.append("Paper calls ambient pO2 21 kPa;97*0.21=20.37 kPa. Preserve both.")
            elif g=="GSE308672":
                m=re.search(r"(\d+)% oxygen",props.get("treatment",""))
                frac=float(m[1])/100 if m else None
                frac_basis="GEO reported volume fraction"
                duration=4; age_value=5
                notes.append("No total pressure reported; do not assume101.325 kPa")
            if g!="GSE308672":
                age_value=int(age[1]) if age else None
            tissue=props.get("tissue",fields.get("Sample_source_name_ch1",[""])[0])
            organ="roots" if "root" in tissue.lower() else ("shoots" if "shoot" in tissue.lower() else tissue)
            title_organ="roots" if title.lower().startswith("root ") else ("shoots" if title.lower().startswith("shoot ") else None)
            organ_conflict=title_organ is not None and organ!=title_organ
            if organ_conflict:
                notes.append(f"ORGAN CONFLICT: title={title_organ}, characteristics={organ}; do not silently resolve")
                organ="unresolved: "+title_organ+" title / "+organ+" characteristics"
            if g=="GSE87903" and age_value==11:
                notes.append("GEO age11 days versus paper10-day start; start/harvest age basis unresolved")
            primary=g in DIRECT or g=="GSE308672"
            rows.append({
                "study_id":g,"sample_id":gsm,"series_memberships":entry["series"],
                "sample_title":title,"organ":organ,"ecotype":props.get("ecotype",props.get("ecotype/background")),
                "age_days_reported":age_value,"age_basis":"GEO protocol/paper seedling age" if g=="GSE308672" else "GEO age field; start/harvest basis not harmonized",
                "organ_from_characteristics":tissue,"organ_from_title":title_organ,
                "organ_conflict":organ_conflict,"reported_characteristics":chars,
                "pressure_text":exp or None,"pressure_basis":"absolute chamber setpoint" if p else None,
                "pressure_kpa":p,"oxygen_fraction":frac,"oxygen_fraction_basis":frac_basis,
                "po2_reported_kpa":p02,"po2_derived_kpa":oxygen_partial_pressure(p,frac),
                "duration_hours":duration,"replicate_label":rep[1] if rep else None,
                "independence":"Array/library record; chamber/sample independence requires design mapping",
                "chamber_id":None,"batch_id":None,
                "co2_reported":"0.05 kPa, paper" if g in DIRECT else None,
                "temperature_reported":"22–24 C, paper" if g in DIRECT else None,
                "humidity_reported":">=95% at plate, paper" if g in DIRECT else None,
                "light_reported":"continuous70–80 umol m-2 s-1, paper" if g in DIRECT else ("4 h treatment in dark" if g=="GSE308672" else None),
                "audit_scope":"all priority study samples" if primary else "representative only; not complete study",
                "source_url":entry["provenance"]["url"],"source_sha256":entry["provenance"]["sha256"],
                "retrieved_utc":entry["provenance"]["retrieved_utc"],
                "notes":"; ".join(notes)})
    return rows

def build(repo, output):
    repo,output=Path(repo),Path(output)
    snapshot=read_json(repo/"data/snapshot/public_facts_2026-10-15.json")
    studies=read_json(repo/"curation/studies.json")
    atlases=read_json(repo/"curation/atlases.json")
    decisions=read_json(repo/"curation/decisions.json")
    rows=[]
    for s in studies:
        r={"organism":"Arabidopsis thaliana","snapshot_date":snapshot["snapshot_date"],**s}
        if s["study_id"] in snapshot["series"]:
            fields=snapshot["series"][s["study_id"]]["fields"]
            r["title"]=fields.get("Series_title",[""])[0]
            r["sample_records"]=len(fields.get("Series_sample_id",[]))
            r["platform_ids"]=fields.get("Series_platform_id",[])
        r.setdefault("sample_records",None)
        if s["study_id"] in DIRECT:
            ids=set(snapshot["series"][s["study_id"]]["fields"]["Series_sample_id"])
            r["shared_sample_records_with_other_hypobaria_subseries"]=len(ids.intersection(set().union(*[
                set(snapshot["series"][g]["fields"]["Series_sample_id"]) for g in DIRECT if g!=s["study_id"]])))
        r["validated_definition"]=decisions["validation_definition"]
        rows.append(r)
    rows.sort(key=lambda r:r["study_id"])
    validated=[r for r in rows if r["validated"]]
    samples=sample_audit(snapshot)
    groups=defaultdict(list)
    for r in samples:
        if r["study_id"] in DIRECT or r["study_id"]=="GSE308672":
            key=tuple(r[k] for k in ["study_id","organ","pressure_kpa","po2_reported_kpa","oxygen_fraction","duration_hours"])
            groups[key].append(r)
    group_rows=[]
    for key,vals in sorted(groups.items(),key=lambda x:str(x[0])):
        row=dict(zip(["study_id","organ","pressure_kpa","po2_reported_kpa","oxygen_fraction","duration_hours"],key))
        row.update({"array_or_library_records":len(vals),"sample_ids":[r["sample_id"] for r in vals],
                    "replicate_labels":[r["replicate_label"] for r in vals],
                    "independent_biological_n":None,
                    "warning":"Record count, not automatically biological replication; verify chamber/pool mapping"})
        group_rows.append(row)
    files=list({(f["repository"],f.get("assay_id"),f["filename"],f.get("sample_id")):
                 f for f in snapshot["files"]}.values())
    files.sort(key=lambda r:(r["study_id"],r["repository"],r["filename"]))
    alias_rows=[]
    for r in rows:
        for alias in [r["study_id"]]+r.get("aliases",[]):
            alias_rows.append({"canonical_study_id":r["study_id"],"accession":alias,
                               "normalized_alias":canonical_alias(alias),"relationship":"canonical" if alias==r["study_id"] else "explicit linked accession/version/companion assay; see modality"})
    for sup,children in decisions["super_series"].items():
        alias_rows.append({"canonical_study_id":";".join(children),"accession":sup,"normalized_alias":sup,
                           "relationship":"SuperSeries wrapper, not independent experiment"})
    selected={canonical_alias(a):r["study_id"] for r in rows for a in [r["study_id"]]+r.get("aliases",[])}
    uidmap={r["uid"]:r for r in snapshot["candidate_summaries"]}
    candidates=[]
    for c in snapshot["candidate_occurrences"]:
        cc={**c}; original=str(c["accession_or_uid"])
        if c["repository"]=="GEO" and original in uidmap:
            cc.update({k:uidmap[original].get(k) for k in ["accession","title"]})
        else:
            cc["accession"]=original
        acc=canonical_alias(cc["accession"] or "")
        cc["canonical_study_id"]=selected.get(acc)
        cc["screening_status"]="curated record" if acc in selected else ("SuperSeries wrapper" if acc in decisions["super_series"] else "not shortlisted; relevance not fully audited")
        cc["screening_notes"]="Automated retrieval is a candidate occurrence, not an eligible-study count"
        candidates.append(cc)
    provenance=[]
    for kind,collection in [("series",snapshot["series"]),("sample",snapshot["samples"])]:
        for acc,v in collection.items():
            provenance.append({"entity":acc,"evidence_kind":kind,**v["provenance"]})
    for r in rows:
        for url in r["source_urls"]:
            provenance.append({"entity":r["study_id"],"evidence_kind":"curated primary/repository source",
                               "url":url,"retrieved_utc":"2026-10-15","http_status":None,"sha256":None})
    write_csv(output/"arabidopsis_omics_MASTER.csv",rows)
    columns=list(dict.fromkeys(k for r in rows for k in r))
    write_csv(output/"arabidopsis_omics_VALIDATED.csv",validated,columns)
    write_csv(output/"sample_condition_audit.csv",samples)
    write_csv(output/"condition_group_audit.csv",group_rows)
    write_csv(output/"study_design_audit.csv",[{k:r.get(k) for k in [
        "study_id","conditions","replication","matched_omics","feasibility","limitations","source_urls"]} for r in rows])
    write_csv(output/"file_manifest.csv",files)
    write_csv(output/"atlas_suitability.csv",atlases)
    write_csv(output/"accession_relationships.csv",alias_rows)
    write_csv(output/"search_ledger.csv",snapshot["search_pages"])
    write_csv(output/"supplemental_web_searches.csv",snapshot["web_searches"])
    write_csv(output/"discovery_candidates.csv",candidates)
    write_csv(output/"provenance_ledger.csv",provenance)
    write_csv(output/"additional_lead_decisions.csv",decisions["manual_exclusions"])
    ids=set().union(*[set(snapshot["series"][g]["fields"]["Series_sample_id"]) for g in DIRECT])
    metrics={"master_records":len(rows),"validated_records":len(validated),
        "relevance_counts":dict(Counter(r["relevance"] for r in rows)),
        "hypobaria_subseries":len(DIRECT),"hypobaria_sample_memberships":sum(len(snapshot["series"][g]["fields"]["Series_sample_id"]) for g in DIRECT),
        "unique_hypobaria_gsms":len(ids),"sample_audit_rows":len(samples),
        "unique_sample_metadata_records":len(snapshot["samples"]),"condition_groups":len(group_rows),
        "files_inventoried":len(files),"search_api_pages":len(snapshot["search_pages"]),
        "web_search_queries":len(snapshot["web_searches"]),"candidate_occurrences":len(candidates),
        "nominal_target_pressure_kpa":8.2*PSI_KPA,"nominal_target_oxygen_fraction":.34,
        "nominal_target_po2_kpa":8.2*PSI_KPA*.34}
    (output/"catalog_metrics.json").write_text(json.dumps(metrics,indent=2,sort_keys=True)+"\n")
    validate(repo,output)
    return metrics

def validate(repo,output):
    repo,output=Path(repo),Path(output)
    def read(name):
        with (output/name).open() as f: return list(csv.DictReader(f))
    master=read("arabidopsis_omics_MASTER.csv")
    ids=[r["study_id"] for r in master]
    assert len(ids)==len(set(ids)),"Duplicate canonical records"
    assert all(r["source_urls"] and r["rationale"] for r in master),"Missing evidence/rationale"
    assert all(r["validated"]=="True" for r in read("arabidopsis_omics_VALIDATED.csv"))
    assert not set(ids)&{"GSE87869","GSE87905","GSE14578"},"SuperSeries inflated catalog"
    sample=read("sample_condition_audit.csv")
    assert len({(r["study_id"],r["sample_id"]) for r in sample})==len(sample)
    for r in sample:
        if r["po2_derived_kpa"]:
            assert abs(float(r["pressure_kpa"])*float(r["oxygen_fraction"])-float(r["po2_derived_kpa"]))<1e-8
        if r["study_id"]=="GSE308672":
            assert not r["pressure_kpa"] and not r["po2_derived_kpa"]
    metrics=read_json(output/"catalog_metrics.json")
    assert metrics["unique_hypobaria_gsms"]==130 and metrics["hypobaria_sample_memberships"]==148
    assert "PXD002353" in json.dumps(read("file_manifest.csv")),"Lost companion assay"
    assert len(read("file_manifest.csv"))==metrics["files_inventoried"]
    for filename in output.glob("*.csv"):
        assert filename.stat().st_size>10
    return {"status":"passed","canonical_records":len(master),"unique_hypobaria_gsms":130}

def checksums(folder):
    folder=Path(folder)
    return {p.relative_to(folder).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(folder.rglob("*")) if p.is_file() and p.name!="SHA256SUMS.txt"}
