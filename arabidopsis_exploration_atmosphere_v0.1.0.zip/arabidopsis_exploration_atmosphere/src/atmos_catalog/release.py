"""Allowlisted, credential-free release packaging with integrity manifest."""
import json
from pathlib import Path
import hashlib
import zipfile
import shutil
import tempfile

ALLOW_FILES={"README.md","pyproject.toml","requirements-lock.txt","CITATION.cff",".zenodo.json",
             ".gitignore","LICENSE","LICENSE-DATA","THIRD_PARTY_NOTICES.md","CHANGELOG.md"}
ALLOW_DIRS={"src","tests","config","curation","data","docs","outputs"}

def package(repo,destination):
    repo,destination=Path(repo),Path(destination)
    included=[]
    for p in sorted(repo.rglob("*")):
        rel=p.relative_to(repo)
        if not p.is_file() or any(x.startswith(".") for x in rel.parts[1:]):continue
        if rel.parts[0] not in ALLOW_DIRS and rel.as_posix() not in ALLOW_FILES:continue
        if "__pycache__" in rel.parts or p.suffix in [".pyc",".body",".ipynb"]:continue
        if "execution_trace" in rel.parts or "cache" in rel.parts:raise ValueError("Private artifact in release")
        if p.suffix in [".py",".json",".md",".txt",".toml",".cff",".csv"]:
            text=p.read_text()
            private_roots=tuple("/"+"mnt/"+x+"/" for x in
                ["user-uploads","user-results","skills","shared-workspace","results"])
            private_roots+=("/"+"workspace/",)
            if any(x in text for x in private_roots):
                raise ValueError(f"Private path in {rel}")
        included.append((p,rel))
    manifest="\n".join(hashlib.sha256(p.read_bytes()).hexdigest()+"  "+rel.as_posix() for p,rel in included)+"\n"
    destination.parent.mkdir(parents=True,exist_ok=True)
    # Always write ZIP to a local seekable temporary file, then copy.
    with tempfile.TemporaryDirectory(prefix="atmos-release-") as temp:
        local=Path(temp)/destination.name
        with zipfile.ZipFile(local,"w",compression=zipfile.ZIP_DEFLATED) as z:
            for p,rel in included:
                info=zipfile.ZipInfo("arabidopsis_exploration_atmosphere/"+rel.as_posix(),date_time=(2026,10,15,0,0,0))
                info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
                z.writestr(info,p.read_bytes())
            z.writestr("arabidopsis_exploration_atmosphere/SHA256SUMS.txt",manifest)
        with zipfile.ZipFile(local) as z:assert z.testzip() is None
        shutil.copyfile(local,destination)
    with zipfile.ZipFile(destination) as z:assert z.testzip() is None
    return {"filename":destination.name,"files":len(included)+1,"bytes":destination.stat().st_size,
            "sha256":hashlib.sha256(destination.read_bytes()).hexdigest()}
