"""Configurable repository queries with explicit completeness and failures."""
from __future__ import annotations
import csv
import io
import json
import xml.etree.ElementTree as ET
from pathlib import Path
from .http import MetadataClient

EUTILS = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"
ORG = '"Arabidopsis thaliana"[Organism]'
GEO_TERMS = [
    'hypobaric', 'hypobaria', '"low atmospheric pressure"', '"reduced pressure"',
    '"exploration atmosphere"', '"oxygen enriched"', 'hyperoxia',
    '(hypoxia OR "low oxygen") AND ("single cell" OR "single nucleus" OR "single nuclei" OR snRNA)',
    '(hypobaric OR hypobaria) AND (proteomic OR metabolomic OR methylation OR ATAC)',
    '"Dissecting Low Atmospheric Pressure"', '"Patterns of Arabidopsis gene expression"',
    '"cell-specific" AND hypoxia', '"mild decreases" AND oxygen',
    '"translatome" AND hypoxia', '"oxygen" AND "metabolite profiling"',
    '"shoot and root" AND "single cell"', '"single-cell" AND "root atlas"',
    '"spatial" AND "life cycle"', '"hypoxia" AND (proteomics OR methylation OR "ATAC-seq")',
    '"oxygen" AND "34%"',
]

def default_config():
    jobs = []
    for i, term in enumerate(GEO_TERMS):
        jobs.append({"label":f"geo_{i+1:02}", "repository":"GEO", "kind":"entrez",
                     "db":"gds", "query":f"({ORG}) AND ({term}) AND gse[Entry Type]"})
    for i, term in enumerate(["hypobaric OR hypobaria", '"exploration atmosphere"',
                             'hypoxia AND ("single nuclei" OR "single nucleus")']):
        jobs.append({"label":f"sra_{i+1}", "repository":"SRA", "kind":"entrez",
                     "db":"sra", "query":f"({ORG}) AND ({term})"})
    for word in ["hypobaric", "hypobaria", '"low atmospheric pressure"', '"exploration atmosphere"']:
        jobs.append({"label":f"osdr_{word.strip(chr(34)).replace(' ', '_')}",
                     "repository":"OSDR", "kind":"osdr_search", "query":word})
    jobs.append({"label":"osdr_arabidopsis_assays", "repository":"OSDR BDAPI",
                 "kind":"direct", "url":"https://visualization.osdr.nasa.gov/biodata/api/v2/query/assays/",
                 "params":{"study.characteristics.organism":"Arabidopsis thaliana","format":"csv"}})
    for i, q in enumerate(["Arabidopsis AND (hypobaric OR hypobaria)",
                           'Arabidopsis AND "low oxygen"',
                           'Arabidopsis AND "single nuclei" AND hypoxia']):
        jobs.append({"label":f"biostudies_{i}", "repository":"BioStudies", "kind":"biostudies", "query":q})
    jobs += [
        {"label":"ena_hypobaria", "repository":"ENA", "kind":"direct",
         "url":"https://www.ebi.ac.uk/ena/portal/api/search",
         "params":{"result":"study", "query":'tax_eq(3702) AND (study_title="*hypobar*" OR study_title="*atmospheric pressure*")',
                   "fields":"study_accession,study_title,study_description", "format":"tsv","limit":0}},
        {"label":"pride_pressure", "repository":"PRIDE", "kind":"pride", "query":"Arabidopsis hypobaric"},
        {"label":"pride_hypoxia", "repository":"PRIDE", "kind":"pride", "query":"Arabidopsis hypoxia"},
        {"label":"omicsdi_pressure", "repository":"OmicsDI", "kind":"omicsdi", "query":"Arabidopsis AND hypobaric"},
        {"label":"omicsdi_oxygen", "repository":"OmicsDI", "kind":"omicsdi", "query":"Arabidopsis AND hypoxia AND metabolomics"},
        {"label":"metabolights_pressure", "repository":"MetaboLights", "kind":"direct",
         "url":"https://www.ebi.ac.uk/metabolights/ws/studies/search", "params":{"query":"Arabidopsis hypobaric"}},
        {"label":"workbench_pressure", "repository":"Metabolomics Workbench", "kind":"direct",
         "url":"https://www.metabolomicsworkbench.org/rest/study/study_title/hypobaric/summary/json"},
        {"label":"expression_atlas", "repository":"Expression Atlas", "kind":"direct",
         "url":"https://www.ebi.ac.uk/gxa/json/experiments", "params":{"species":"arabidopsis thaliana"}},
        {"label":"zenodo_search", "repository":"Zenodo", "kind":"direct",
         "url":"https://zenodo.org/api/records", "params":{"q":'Arabidopsis AND (hypobaric OR "low air pressure")',"size":100}},
    ]
    return {"version":"0.1.0", "organism":"Arabidopsis thaliana", "jobs":jobs,
            "max_pages":20, "page_size":100}

def run_discovery(config, cache, output, offline=False, refresh=False):
    output = Path(output); output.mkdir(parents=True, exist_ok=True)
    client = MetadataClient(cache, offline=offline)
    ledger, candidates = [], []
    for job in config["jobs"]:
        kind, label, repo = job["kind"], job["label"], job["repository"]
        total, n, status, comment = None, 0, "complete", ""
        for page in range(config.get("max_pages", 20)):
            size = config.get("page_size", 100)
            if kind == "entrez":
                url = EUTILS + "esearch.fcgi"
                params = {"db":job["db"],"term":job["query"],"retmode":"json","retmax":size,"retstart":page*size}
            elif kind == "osdr_search":
                url = "https://osdr.nasa.gov/osdr/data/search"
                params = {"term":job["query"],"type":"cgene","from":page*size,"size":size,
                          "ffield":"organism","fvalue":"Arabidopsis thaliana"}
            elif kind == "biostudies":
                url = "https://www.ebi.ac.uk/biostudies/api/v1/search"
                params = {"query":job["query"], "pageSize":size,"page":page+1}
            elif kind == "omicsdi":
                url = "https://www.omicsdi.org/ws/dataset/search"
                params = {"query":job["query"],"size":size,"start":page*size}
            elif kind == "pride":
                url = "https://www.ebi.ac.uk/pride/ws/archive/v3/search/projects"
                params = {"keyword":job["query"],"pageSize":size,"page":page}
            else:
                url, params = job["url"], job.get("params")
            text, meta = client.get(url, params, label=label, refresh=refresh)
            try: data = json.loads(text)
            except json.JSONDecodeError: data = None
            row = {**meta,"label":label,"repository":repo,"query":job.get("query",str(params or "")),
                   "page":page,"status":"complete","retrieved_records":None,"total_reported":None,"notes":""}
            if meta["http_status"] != 200:
                row["status"] = "failed"
                row["notes"] = "HTTP/API failure; not evidence of no data"
                ledger.append(row); break
            items = []
            try:
                if kind == "entrez":
                    block = data["esearchresult"]; total = int(block["count"]); items = block["idlist"]
                    for uid in items:
                        candidates.append({"repository":repo,"query":job["query"],"accession_or_uid":uid,"title":""})
                elif kind == "osdr_search":
                    hits = data["hits"]; raw_total=hits["total"]
                    total = int(raw_total.get("value",0) if isinstance(raw_total,dict) else raw_total)
                    items=hits["hits"]
                    for h in items:
                        s=h["_source"]
                        candidates.append({"repository":repo,"query":job["query"],
                            "accession_or_uid":s.get("Accession",""),"title":s.get("Study Title","")})
                elif kind == "biostudies":
                    total = int(data.get("totalHits",0)); items = data.get("hits",[])
                    for h in items:
                        candidates.append({"repository":repo,"query":job["query"],
                                           "accession_or_uid":h.get("accession",""),"title":h.get("title","")})
                elif kind == "omicsdi":
                    items = data.get("datasets",[]); total=int(data.get("count",data.get("total",len(items))))
                    for h in items:
                        candidates.append({"repository":str(h.get("source",repo)),"query":job["query"],
                                           "accession_or_uid":h.get("id",""),"title":h.get("name","")})
                elif kind == "pride":
                    items = data if isinstance(data,list) else data.get("_embedded",{}).get("projects",[])
                    total = data.get("page",{}).get("totalElements") if isinstance(data,dict) else None
                    if isinstance(data,dict) and "page" not in data:
                        row["status"]="needs_manual_review"
                        row["notes"]="Search pagination schema not confirmed"
                    for h in items:
                        if "arabidopsis" in str(h).lower() and any(w in str(h).lower() for w in ["hypox","hypobar","pressure"]):
                            candidates.append({"repository":repo,"query":job["query"],
                                "accession_or_uid":h.get("accession",""),"title":h.get("title","")})
                elif "text/html" in meta.get("content_type",""):
                    row["status"]="unexpected_html"
                    row["notes"]="HTML returned instead of expected API metadata"
                elif repo == "ENA":
                    items=list(csv.DictReader(io.StringIO(text),delimiter="\t")); total=len(items)
                    for h in items:
                        candidates.append({"repository":repo,"query":str(params),
                            "accession_or_uid":h.get("study_accession",""),"title":h.get("study_title","")})
                elif repo == "OSDR BDAPI":
                    items=list(csv.DictReader(io.StringIO(text))); total=len(items)
                elif repo == "Expression Atlas" and isinstance(data,dict):
                    items=data.get("experiments",[]); total=len(items)
                    for h in items:
                        hs=str(h).lower()
                        if "arabidopsis" in hs and any(w in hs for w in ["hypobar","hypox","low oxygen"]):
                            candidates.append({"repository":repo,"query":"Arabidopsis pressure/oxygen",
                               "accession_or_uid":h.get("experimentAccession",""),"title":h.get("experimentDescription","")})
                elif repo == "Zenodo" and isinstance(data,dict):
                    items=data.get("hits",{}).get("hits",[]); total=data.get("hits",{}).get("total")
                else:
                    row["status"]="needs_manual_review"
                    row["notes"]="API response retained; result schema not treated as a validated zero"
                row["retrieved_records"],row["total_reported"]=len(items),total
                ledger.append(row)
                n += len(items)
                if kind == "pride" and isinstance(data,list) and len(items)==size:
                    continue
                if kind == "direct" or total is None or n >= total:
                    break
                if not items:
                    row["status"]="incomplete"; row["notes"]="Empty page before reported total"; break
            except (TypeError, KeyError, ValueError) as exc:
                row["status"]="schema_error"; row["notes"]=str(exc); ledger.append(row); break
        else:
            ledger[-1]["status"]="truncated"
            ledger[-1]["notes"]="Configured page budget exhausted; coverage incomplete"
        print(f"{label}: {ledger[-1]['status']} n={n} total={total}")
    (output/"discovery_ledger.json").write_text(json.dumps(ledger,indent=2))
    (output/"discovery_candidates.json").write_text(json.dumps(candidates,indent=2))
    return ledger, candidates

def parse_geo_soft(text):
    """Parse SOFT metadata only; measurement tables are never consumed."""
    fields = {}
    for line in text.splitlines():
        if line.startswith("!"):
            key, sep, value=line.partition(" = ")
            if sep:
                fields.setdefault(key[1:],[]).append(value.strip())
    return fields

def fetch_known_metadata(cache, output, gses, osds, offline=False):
    output=Path(output); output.mkdir(parents=True,exist_ok=True)
    client=MetadataClient(cache,offline=offline)
    index={"geo":{},"osdr":{}}
    for accession in gses:
        text,meta=client.get("https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi",
            {"acc":accession,"targ":"self","form":"text","view":"full"},label=accession)
        parsed=parse_geo_soft(text)
        index["geo"][accession]={"metadata":parsed,"provenance":meta}
        print(accession,parsed.get("Series_title"), "GSMs:",len(parsed.get("Series_sample_id",[])))
    for number in osds:
        data,meta=client.json(f"https://osdr.nasa.gov/osdr/data/osd/meta/{number}",label=f"OSD-{number}")
        files,fmeta=client.json(f"https://osdr.nasa.gov/osdr/data/osd/files/{number}",
                                {"page":1,"size":25},label=f"OSD-{number}-files")
        file_pages=[{"data":files,"provenance":fmeta}]
        if isinstance(files,dict):
            for page in range(2,int(files.get("page_total",1))+1):
                nextfiles,nextmeta=client.json(f"https://osdr.nasa.gov/osdr/data/osd/files/{number}",
                                      {"page":page,"size":25},label=f"OSD-{number}-files")
                file_pages.append({"data":nextfiles,"provenance":nextmeta})
        index["osdr"][f"OSD-{number}"]={"metadata":data,"provenance":meta,"file_pages":file_pages}
        study=(data or {}).get("study",{}).get(f"OSD-{number}",{})
        print(f"OSD-{number}",str(study.get("additionalInformation",{}).get("description",""))[:100])
    (output/"metadata_index.json").write_text(json.dumps(index,indent=2))
    client.save_events(output/"metadata_events.json")
    return index
