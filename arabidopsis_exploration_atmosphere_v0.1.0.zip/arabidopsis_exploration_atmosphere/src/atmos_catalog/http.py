"""Bounded, cached public metadata requests; no measurement-file downloads."""
from __future__ import annotations
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse, urljoin, parse_qs, unquote
import requests

ALLOWED_HOSTS = {
    "osdr.nasa.gov", "visualization.osdr.nasa.gov",
    "eutils.ncbi.nlm.nih.gov", "www.ncbi.nlm.nih.gov",
    "www.ebi.ac.uk", "www.omicsdi.org", "zenodo.org",
    "www.metabolomicsworkbench.org", "www.arabidopsis.org", "ftp.ncbi.nlm.nih.gov",
}
BLOCKED_PARTS = ("/download", "/files-archive", "/supplementary/", "/suppl/",
                 ".fastq", ".fq.gz", ".bam", ".h5ad", ".loom",
                 ".xlsx", ".cel", ".rds", ".mtx", ".raw", ".mzml",
                 ".tar", ".zip", "/api/records/export")

def check_metadata_url(url):
    parsed=urlparse(url)
    if parsed.scheme != "https" or parsed.hostname not in ALLOWED_HOSTS:
        raise ValueError("Only HTTPS metadata requests to approved hosts are allowed")
    path=unquote(parsed.path).lower()
    if any(part in path for part in BLOCKED_PARTS):
        raise ValueError(f"Measurement/download endpoint forbidden: {path}")
    q={k.lower():v for k,v in parse_qs(parsed.query).items()}
    if any(str(x).upper().startswith("GSM") for x in q.get("acc",[])):
        if q.get("view") != ["brief"] or q.get("targ") != ["self"]:
            raise ValueError("GSM requests require self/brief metadata-only views")

def utcnow():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

class MetadataClient:
    def __init__(self, cache, offline=False, max_bytes=25_000_000, delay=0.36):
        self.cache = Path(cache)
        self.cache.mkdir(parents=True, exist_ok=True)
        self.offline, self.max_bytes, self.delay = offline, max_bytes, delay
        self.events = []
        self.session = requests.Session()
        self.session.headers["User-Agent"] = "ArabidopsisAtmosphereCatalog/0.1.0 (public metadata research)"

    def get(self, url, params=None, label="", refresh=False):
        prepared = requests.Request("GET", url, params=params).prepare().url
        check_metadata_url(prepared)
        key = hashlib.sha256(prepared.encode()).hexdigest()
        body_path = self.cache / f"{key}.body"
        meta_path = self.cache / f"{key}.json"
        if not refresh and body_path.exists() and meta_path.exists():
            meta = json.loads(meta_path.read_text())
            self.events.append({**meta, "label": label, "cache_hit": True})
            return body_path.read_text(encoding="utf-8", errors="replace"), meta
        if self.offline:
            raise FileNotFoundError(f"Not in offline metadata cache: {prepared}")
        t0 = time.monotonic()
        error, response, blob = "", None, b""
        for attempt in range(3):
            try:
                time.sleep(self.delay)
                current=prepared
                for redirect in range(6):
                    check_metadata_url(current)
                    response = self.session.get(current, timeout=(15, 50), stream=True, allow_redirects=False)
                    if response.status_code not in (301,302,303,307,308):
                        break
                    current=urljoin(current,response.headers.get("Location",""))
                    response.close()
                else:
                    raise ValueError("Metadata redirect limit exceeded")
                if response.status_code == 429 or response.status_code >= 500:
                    if attempt < 2:
                        response.close()
                        time.sleep(2 ** (attempt + 1))
                        continue
                length = int(response.headers.get("Content-Length", 0))
                if length > self.max_bytes:
                    raise ValueError(f"Metadata size exceeds cap: {length}")
                chunks, size = [], 0
                for chunk in response.iter_content(65536):
                    size += len(chunk)
                    if size > self.max_bytes:
                        raise ValueError("Metadata response exceeded streaming cap")
                    chunks.append(chunk)
                blob = b"".join(chunks)
                error = ""
                break
            except (requests.RequestException, ValueError) as exc:
                error = str(exc)
                if attempt < 2:
                    time.sleep(2 ** (attempt + 1))
            finally:
                if response is not None:
                    response.close()
        status = response.status_code if response is not None else 0
        if not blob and error:
            status = 0
        meta = {
            "url": prepared, "retrieved_utc": utcnow(), "http_status": status,
            "bytes": len(blob), "seconds": round(time.monotonic() - t0, 3),
            "sha256": hashlib.sha256(blob).hexdigest(), "error": error,
            "content_type": response.headers.get("Content-Type", "") if response is not None else "",
        }
        body_path.write_bytes(blob)
        meta_path.write_text(json.dumps(meta, indent=2))
        self.events.append({**meta, "label": label, "cache_hit": False})
        return blob.decode("utf-8", errors="replace"), meta

    def json(self, url, params=None, **kwargs):
        text, meta = self.get(url, params, **kwargs)
        try:
            return json.loads(text), meta
        except json.JSONDecodeError:
            return None, {**meta, "parse_error": "Response was not valid JSON"}

    def save_events(self, destination):
        Path(destination).write_text(json.dumps(self.events, indent=2))
