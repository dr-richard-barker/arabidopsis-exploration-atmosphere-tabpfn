"""Small explicit CLI: live discovery is separate from frozen offline builds."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
from .catalog import build, validate, read_json
from .discovery import default_config, run_discovery, fetch_known_metadata
from .reporting import report
from .release import package

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--repo",type=Path,default=Path(__file__).resolve().parents[2])
    sub=p.add_subparsers(dest="command",required=True)
    b=sub.add_parser("build");b.add_argument("--output",type=Path)
    v=sub.add_parser("validate");v.add_argument("--output",type=Path)
    r=sub.add_parser("report");r.add_argument("--output",type=Path)
    z=sub.add_parser("package");z.add_argument("--zip",type=Path,required=True)
    d=sub.add_parser("discover")
    d.add_argument("--config",type=Path)
    d.add_argument("--work",type=Path,required=True,help="Private working directory for API cache and review candidates")
    d.add_argument("--refresh",action="store_true",help="Required opt-in for live network discovery")
    d.add_argument("--fetch-known",action="store_true",help="Also fetch curated GEO/OSDR metadata; no sample measurement tables")
    a=p.parse_args(argv)
    out=getattr(a,"output",None) or a.repo/"outputs/tables"
    if a.command=="build":
        print(json.dumps(build(a.repo,out),indent=2))
    elif a.command=="validate":
        print(json.dumps(validate(a.repo,out),indent=2))
    elif a.command=="report":
        print(json.dumps(report(a.repo,out.parent/"reports",out),indent=2))
    elif a.command=="package":
        print(json.dumps(package(a.repo,a.zip),indent=2))
    else:
        if not a.refresh:
            p.error("Live discovery requires --refresh; frozen build is offline and does not need discover.")
        stamp=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        dest=a.work/stamp
        config=read_json(a.config) if a.config else default_config()
        ledger,candidates=run_discovery(config,a.work/"cache",dest,refresh=True)
        if a.fetch_known:
            studies=read_json(a.repo/"curation/studies.json")
            gses=[s["study_id"] for s in studies if s["study_id"].startswith("GSE")]
            fetch_known_metadata(a.work/"cache",dest,gses,[134,136])
        print(json.dumps({"new_review_snapshot":str(dest),"pages":len(ledger),"candidate_occurrences":len(candidates),
            "warning":"New hits require curation. Frozen release snapshot and decisions were not changed."},indent=2))

if __name__=="__main__":
    main()
