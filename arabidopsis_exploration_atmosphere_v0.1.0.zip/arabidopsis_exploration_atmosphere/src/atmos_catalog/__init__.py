"""Metadata-only Arabidopsis exploration-atmosphere catalog."""
__version__ = "0.1.0"
