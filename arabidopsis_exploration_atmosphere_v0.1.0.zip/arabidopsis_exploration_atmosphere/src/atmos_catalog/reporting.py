"""Shared Markdown/Word scientific report generation."""
from pathlib import Path
import json
import re
import shutil
import tempfile
import zipfile
import xml.etree.ElementTree as ET
from collections import Counter
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.opc.constants import RELATIONSHIP_TYPE as RT

def validate_report_pair(markdown,word):
    """Read saved deliverables and compare all scientific text, including tables."""
    text=Path(markdown).read_text()
    lines=[line for line in text.splitlines() if not re.fullmatch(r"[|:\- ]+",line)]
    plain="\n".join(re.sub(r"^(?:#+ |\d+\. |- )","",line) for line in lines)
    plain=re.sub(r"\[([^\]]+)\]\((https?://[^)]+)\)",r"\1",plain)
    plain=plain.replace("**","").replace("`","")
    ns="{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    with zipfile.ZipFile(word) as archive:
        assert archive.testzip() is None
        root=ET.fromstring(archive.read("word/document.xml"))
    rendered=" ".join(e.text or "" for e in root.iter(ns+"t"))
    assert Counter(re.findall(r"\w+",plain))==Counter(re.findall(r"\w+",rendered)), "Report content mismatch"
    doc=Document(word)
    for table in doc.tables:
        assert table.alignment==WD_TABLE_ALIGNMENT.CENTER
        assert sum(c.width for c in table.columns)<=Inches(6.51)
        assert table.rows[0]._tr.find(".//"+ns+"tblHeader") is not None
    return {"word_paragraphs":len(doc.paragraphs),"word_tables":len(doc.tables),
            "word_hyperlinks":len(list(root.iter(ns+"hyperlink"))),
            "all_text_and_tables_match_markdown":True,"table_layout_structural_checks":"passed",
            "visual_render_review":"Not performed; no embedded figures"}

def rich(paragraph,text):
    """Minimal links, inline code and bold; source numbers stay unchanged."""
    for token in re.split(r"(\[[^\]]+\]\(https?://[^)]+\)|\*\*[^*]+\*\*|`[^`]+`)",text):
        if not token: continue
        m=re.fullmatch(r"\[([^\]]+)\]\((https?://[^)]+)\)",token)
        if m:
            link=OxmlElement("w:hyperlink")
            link.set(qn("r:id"),paragraph.part.relate_to(m[2],RT.HYPERLINK,is_external=True))
            run=OxmlElement("w:r");prop=OxmlElement("w:rPr")
            font=OxmlElement("w:rFonts");font.set(qn("w:ascii"),"Arial");font.set(qn("w:hAnsi"),"Arial")
            prop.append(font)
            color=OxmlElement("w:color");color.set(qn("w:val"),"0563C1");prop.append(color)
            run.append(prop);t=OxmlElement("w:t");t.text=m[1];run.append(t);link.append(run)
            paragraph._p.append(link)
        else:
            run=paragraph.add_run(token.strip("`").replace("**",""))
            run.bold=token.startswith("**")
            run.font.name="Arial"

def markdown_to_docx(markdown,dest):
    doc=Document()
    sec=doc.sections[0]
    sec.page_width=Inches(8.5);sec.page_height=Inches(11)
    sec.top_margin=sec.bottom_margin=sec.left_margin=sec.right_margin=Inches(1)
    normal=doc.styles["Normal"];normal.font.name="Arial";normal.font.size=Pt(11)
    normal.font.color.rgb=RGBColor.from_string("2C2A26")
    normal.paragraph_format.space_after=Pt(8)
    normal.paragraph_format.line_spacing=1.12
    for name,size in [("Title",26),("Heading 1",18),("Heading 2",14),("Heading 3",12)]:
        doc.styles[name].font.name="Arial";doc.styles[name].font.size=Pt(size)
        doc.styles[name].font.color.rgb=RGBColor.from_string("111111")
    h=sec.header.paragraphs[0];run=h.add_run("Arabidopsis exploration-atmosphere omics")
    run.font.name="Arial";run.font.size=Pt(9);run.font.color.rgb=RGBColor.from_string("8A8378")
    border=OxmlElement("w:pBdr");bottom=OxmlElement("w:bottom")
    for k,v in [("val","single"),("sz","6"),("color","D4A04A"),("space","4")]:bottom.set(qn("w:"+k),v)
    border.append(bottom);h._p.get_or_add_pPr().append(border)
    f=sec.footer.paragraphs[0];f.alignment=WD_ALIGN_PARAGRAPH.CENTER
    run=f.add_run("Page ");run.font.name="Arial";run.font.size=Pt(8)
    field=OxmlElement("w:fldSimple");field.set(qn("w:instr"),"PAGE");f._p.append(field)
    lines=markdown.splitlines();i=0
    while i<len(lines):
        line=lines[i].strip()
        if not line: i+=1;continue
        if line.startswith("|"):
            block=[]
            while i<len(lines) and lines[i].strip().startswith("|"):
                cells=[x.strip() for x in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-+:?",x) for x in cells):block.append(cells)
                i+=1
            cols=len(block[0]);t=doc.add_table(rows=1,cols=cols)
            t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
            for c in t.columns:c.width=Inches(6.5/cols)
            for ri,row in enumerate(block):
                cells=t.rows[0].cells if ri==0 else t.add_row().cells
                for cell,text in zip(cells,row):
                    cell.width=Inches(6.5/cols)
                    rich(cell.paragraphs[0],text)
                    for run in cell.paragraphs[0].runs:
                        run.font.name="Arial";run.font.size=Pt(9)
                        if ri==0:run.bold=True;run.font.color.rgb=RGBColor(255,255,255)
                    shade=OxmlElement("w:shd");shade.set(qn("w:val"),"clear")
                    shade.set(qn("w:fill"),"D4A04A" if ri==0 else ("F9F7F3" if ri%2 else "FFFFFF"))
                    cell._tc.get_or_add_tcPr().append(shade)
                    mar=OxmlElement("w:tcMar")
                    for side in ["top","bottom","start","end"]:
                        el=OxmlElement("w:"+side);el.set(qn("w:w"),"80");el.set(qn("w:type"),"dxa");mar.append(el)
                    cell._tc.get_or_add_tcPr().append(mar)
                if ri==0:
                    repeat=OxmlElement("w:tblHeader");t.rows[0]._tr.get_or_add_trPr().append(repeat)
            doc.add_paragraph()
            continue
        if line.startswith("# "):
            p=doc.add_paragraph(style="Title");rich(p,line[2:])
        elif line.startswith("## "):
            p=doc.add_heading(level=1);rich(p,line[3:])
        elif line.startswith("### "):
            p=doc.add_heading(level=2);rich(p,line[4:])
        elif line.startswith("- "):
            p=doc.add_paragraph(style="List Bullet");rich(p,line[2:])
        elif re.match(r"^\d+\. ",line):
            p=doc.add_paragraph(style="List Number");rich(p,re.sub(r"^\d+\. ","",line))
        else:
            p=doc.add_paragraph();rich(p,line)
        i+=1
    doc.core_properties.author="Richard John Barker"
    doc.core_properties.title="Arabidopsis exploration-atmosphere omics: catalog and feasibility audit"
    doc.core_properties.subject="Public metadata only; version0.1.0"
    doc.save(dest)

def report(repo, output, tables):
    repo,output,tables=Path(repo),Path(output),Path(tables)
    output.mkdir(parents=True,exist_ok=True)
    metrics=json.loads((tables/"catalog_metrics.json").read_text())
    text=(repo/"docs/report_template.md").read_text()
    for key,value in metrics.items():
        if not isinstance(value,dict):
            text=text.replace("{{"+key+"}}",str(value))
    if re.search(r"\{\{.+?\}\}",text):raise ValueError("Unresolved report token")
    stem="report_arabidopsis_exploration_atmosphere"
    md=output/(stem+".md");md.write_text(text)
    with tempfile.TemporaryDirectory(prefix="atmos-report-") as temp:
        local=Path(temp)/(stem+".docx")
        markdown_to_docx(text,local)
        shutil.copyfile(local,output/local.name)
    check=Document(output/(stem+".docx"))
    assert len(check.tables)>=4 and len(check.paragraphs)>=40
    assert any("130" in p.text for p in check.paragraphs)
    for t in check.tables:
        assert t.alignment==WD_TABLE_ALIGNMENT.CENTER
        assert sum(c.width for c in t.columns)<=Inches(6.51)
    validate_report_pair(md,output/(stem+".docx"))
    return {"markdown":md.name,"word":stem+".docx","tables":len(check.tables),
            "paragraphs":len(check.paragraphs),"visual_render_review":"Not performed; no embedded figures; structural validation passed"}
